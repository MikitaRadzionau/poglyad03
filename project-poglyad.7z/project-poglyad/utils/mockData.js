const vidInfo =[
    {
        name:"Kuplinov ► Play",
        video:"ДОЛГОЖДАННЫЙ КИБЕРПАНК ► Cyberpunk 2077 #1",
        image:'https://i.ytimg.com/vi/K9Dz8tFBuHY/maxresdefault.jpg',
        view:"8.3 mil",
        data:"2 года назад",
    },
    {
        name:"Dream",
        video:"Minecraft Speedrunner VS 5 Hunters GRAND FINALE.",
        image:'https://i.ytimg.com/vi/cIY95KCnnNk/maxresdefault.jpg',
        view:"59 mil",
        data:"1 год назад",
    },
    {
        name:"Marmok",
        video:"Страха нет (Father's Day)",
        image:'https://i.ytimg.com/vi/IEZ_OMrAWl8/maxresdefault.jpg',
        view:"3.8 mil",
        data:"3 месяцев назад",
    },
    {
        name:"MrBeast",
        video:"1,000 Незрячих Людей Видят Впервые",
        image:'https://i.ytimg.com/vi/TJ2ifmkGGus/maxresdefault.jpg',
        view:"145 mil",
        data:"4 месяцев назад",
    },
    {
        name:"DorrianKarnett",
        video:"Что Добавили в НОВЫЙ Adobe Photoshop 2021 - Обзор и Что Нового?",
        image:'https://i.ytimg.com/vi/9Qo_TZIP9J0/maxresdefault.jpg',
        view:"22 k",
        data:"2 года назад",
    },
    {
        name:"Marmok",
        video:"Хорошие игры #27 'Баги, Приколы, Фейлы'",
        image:'https://i.ytimg.com/vi/K9Dz8tFBuHY/maxresdefault.jpg',
        view:"6 mil",
        data:"2 года назад",
    },
]

module.exports = {
    vidInfo,
}