const express = require('express'),
      path = require('path'),
      app = express(),
      PORT = 8900,
      icon='https://yt3.ggpht.com/ytc/AKedOLTagvh8s3siuvX68Oy5AqfL1H6cpyuuWQPcbc0zhg=s900-c-k-c0x00ffffff-no-rj',
      createPath = (page) => path.resolve(__dirname, 'ejs-views', `${page}.ejs`);

app.set('view engine', 'ejs');



app.listen(PORT, (error) => {
  error ? console.log(error) : console.log(`👽стартуем на порту  ${PORT}`);
});



app.use(express.static('styles'));

app.get('/', (req, res) => {
  const title = 'Welcome';
  res.render(createPath('index'), { title,icon });
});
app.get('/home', (req, res) => {
  const title = 'Home';
  const {vidInfo} = require("./utils/mockData");
vidInfo.forEach(video=>{
    console.log(`${video.name} - ${video.view} `);
})
  res.render(createPath('main'), { title,icon });
});

app.get('/profile', (req, res) => {
  const title = 'My Channel';
  res.render(createPath('profile'), {title,icon });
});

app.get('/add-video', (req, res) => {
  const title = 'Add video';
  res.render(createPath('add-video'), { title,icon });
});
app.get('/play-video', (req, res) => {
  const title = 'Play video';
  res.render(createPath('play-video'), { title,icon });
});

app.use((req, res) => {
  const title = 'Error Page';
  res
    .status(404)
    .render(createPath('error'), { title,icon });
});
